/*	Author: Dexter Barrows
	Github: dbarrows.github.io
	*/

#include <cmath>
#include <cstdlib>

float randu();
float randn();
int poissrand(int lambda);