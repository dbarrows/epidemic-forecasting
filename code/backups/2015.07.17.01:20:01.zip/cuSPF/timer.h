#include <sys/time.h>
#include <time.h>
#include <cmath>

int timeval_subtract (double *result, struct timeval *x, struct timeval *y);
int check_float(float x,float y);