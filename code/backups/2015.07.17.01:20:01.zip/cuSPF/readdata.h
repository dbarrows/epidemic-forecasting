#include <string>

int * getData(std::string filename, int * xdim, int * ydim);