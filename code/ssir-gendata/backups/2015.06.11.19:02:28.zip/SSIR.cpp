#include <iostream>
#include <cmath>
#include <fstream>

#define T 		100			// time to simulate over
#define R0 		4.0			// infectiousness
#define r 		1e-1		// recovery rate
#define N 		500 		// population size
#define B 		R0*r/N		// transmission factor
#define merr 	10  		// measurement error
#define alp 	1e-2		// cooling parameter for neighbour interactions

struct SIR {
	float S;
	float I;
	float R;
};

void exp_euler_SIR(float h, float t0, float tn, float * y);
void exp_euler_SSIR(float h, float t0, float tn, SIR * sir, float * neiInf);
int timeval_subtract (double *result, struct timeval *x, struct timeval *y);
int check_float(float x,float y);

using namespace std;

int main () {

	//cout << "Hi there" << endl;

	SIR population[100];
	int adjMat[100][8];


	// populate adjacentcy matrix
	int inds_check[8] = {-11, -10, -9, -1, 1, 9, 10, 11};

	for (int i = 0; i < 100; i++) {
		int i_cell = i / 10;
		int j_cell = i % 10;
		for (int j = 0; j < 8; j++) {
			int nei_ind = i + inds_check[j];
			int i_ref = nei_ind / 10;
			int j_ref = nei_ind % 10;
			if (nei_ind >= 0 && nei_ind < 100 && abs(i_cell - i_ref) <= 1 && abs(j_cell - j_ref) <= 1 ) {
				adjMat[i][j] = nei_ind;
			} else {
				adjMat[i][j] = -1;
			}
		}
	}


	int init_infected = 5;

	population[0].S = N - init_infected;
	population[0].I = init_infected;
	population[0].R = 0;

	for (int i = 1; i < 100; i++) {
		population[i].S = 500;
		population[i].I = 0;
		population[i].R = 0;
	}

	float i_infec = 5;

	//float y[3] = {N - i_infec, i_infec, 0}; 	// 495 susceptible, 5 infected, 0 recovered
	SIR sir = {.S = N - i_infec, .I = i_infec, .R = 0};

	float y_true[T];			// true number of infected peeps

	float fake_neiInf[8] = {0, 0, 0, 0, 0, 0, 0, 0};

	// generate our true trajectory and noisy observation data
	y_true[0] = sir.I;

	for (int t = 1; t < 60; t++) {
		for (int cell = 0; cell < 100; cell++) {
			float neiInf[8];
			for (int i = 0; i < 8; i++) {
				int nei_ind = adjMat[cell][i];
				if (nei_ind >=0 )
					neiInf[i] = population[nei_ind].I; 
			}
			SIR * cell_sir = &population[cell];
			exp_euler_SSIR( 1.0/100, 0.0, 1.0, cell_sir, neiInf);
		}
		exp_euler_SSIR( 1.0/100, 0.0, 1.0, &sir, fake_neiInf);
		y_true[t] = sir.I;
	}


	/*
	string filename("ssir.dat");

    printf("Writing results to file '%s'...\n", filename.c_str());

	FILE * out = fopen(filename.c_str(), "w");

	for (int t = 0; t < T; t++) {
		fprintf(out, "%d ", t);
		fprintf(out, "%f", y_true[t]);
		fprintf(out, "\n");
	}

	fclose(out);

	printf("Plotting using gnuplot...\n");
	printf("Press ENTER close plot and continue\n");

	string syscall("gnuplot -e \"filename='");
	syscall += filename;
	syscall += "'\" pf.plg";

	system( syscall.c_str() );
	*/


	// MATLAB OUT *********************************************************
	// ********************************************************************

	ofstream file;
	file.open ("mat_data.dat");

	for (int cell = 0; cell < 100; cell++) {
		file << population[cell].I;
		if ( (cell-9) % 10 == 0)
			file << endl;
		else
			file << " ";
	}


	file.close();
	return 0;


}

void exp_euler_SIR(float h, float t0, float tn, float * y) {
	
	//float t = t0;

	int num_steps = floor( (tn-t0) / h );

	float S = y[0];
	float I = y[1];
	float R = y[2];

	for(int i = 0; i < num_steps; i++) {
		// get derivatives
		float dS = - B*S*I;
		float dI = B*S*I - r*I;
		float dR = r*I;
		// step forward by h
		S += h*dS;
		I += h*dI;
		R += h*dR;
	}

	y[0] = S;
	y[1] = I;
	y[2] = R;

}


void exp_euler_SSIR(float h, float t0, float tn, SIR * sir, float * neiInf) {
	
	//float t = t0;

	int num_steps = floor( (tn-t0) / h );

	float S = sir->S;
	float I = sir->I;
	float R = sir->R;

	float neiInf_sum = 0;
	for (int i = 0; i < 8; i++)
		neiInf_sum += neiInf[i];

	for(int i = 0; i < num_steps; i++) {
		// get derivatives
		float dS = - B*S*I - alp*B*S*(neiInf_sum);
		float dI = -dS - r*I;
		float dR = r*I;
		// step forward by h
		S += h*dS;
		I += h*dI;
		R += h*dR;
	}

	sir->S = S;
	sir->I = I;
	sir->R = R;

}

int timeval_subtract (double *result, struct timeval *x, struct timeval *y) {

    struct timeval result0;

    /* Perform the carry for the later subtraction by updating y. */
    if (x->tv_usec < y->tv_usec) {
        int nsec = (y->tv_usec - x->tv_usec) / 1000000 + 1;
        y->tv_usec -= 1000000 * nsec;
        y->tv_sec += nsec;
    }
    if (x->tv_usec - y->tv_usec > 1000000) {
        int nsec = (y->tv_usec - x->tv_usec) / 1000000;
        y->tv_usec += 1000000 * nsec;
        y->tv_sec -= nsec;
    }

    /* Compute the time remaining to wait.
     tv_usec is certainly positive. */
    result0.tv_sec = x->tv_sec - y->tv_sec;
    result0.tv_usec = x->tv_usec - y->tv_usec;
    *result = ((double)result0.tv_usec)/1e6 + (double)result0.tv_sec;

    /* Return 1 if result is negative. */
    return x->tv_sec < y->tv_sec;
}

int check_float(float x,float y) {

    float rel_err; 
    float tol=0.00001f;

    rel_err= fabsf(x-y) / y;

    if(rel_err>tol) return 0;
    else return 1;
}