function surfSIR

	data = textread('mat_data.dat')

	len = length(data);

	xx = 1:len;

	[X,Y] = meshgrid(xx,xx);

	Z = data;

	surf(X,Y,Z)

end